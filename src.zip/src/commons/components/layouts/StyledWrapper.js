import React from 'react';
import styled from 'styled-components';

export const StyledWrapper = styled.div`
    
`;
