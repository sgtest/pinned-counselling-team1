const userStatus = {
  EMPLOYED: '재직',
  LEAVE: '휴직',
  RESIGN: '퇴사',
  ONCLASS: '수업 중',
  OUTCLASS: '수업 종료',
};

export default userStatus;
