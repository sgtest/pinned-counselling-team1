const userType = {
  STUDENT: '학생',
  PROFESSOR: '지도교수',
  COUNSELOR: '상담원',
  ADMIN: '관리자',
};

export default userType;
