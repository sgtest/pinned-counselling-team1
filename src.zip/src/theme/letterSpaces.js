const letterSpacings = [
  '0.06px',
  '0.07px',
  '0.08px',
  '0.09px',
  '0.1px',
  '0.1px',
];

export default letterSpacings;
