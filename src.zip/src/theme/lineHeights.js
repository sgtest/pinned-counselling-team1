const lineHeights = ['17px', '19px', '22px', '26px', '28px', '37px'];

export default lineHeights;
