export default function Home() {
  return <h1>테스트</h1>;
}
