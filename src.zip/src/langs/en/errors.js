const errors = {

};

export default errors;