const validations = {};

export default validations;
