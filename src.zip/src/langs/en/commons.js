const commons = {};

export default commons;
