const commons = {
  아이디: '아이디',
  약관에_동의: '약관에 동의합니다',
};

export default commons;
